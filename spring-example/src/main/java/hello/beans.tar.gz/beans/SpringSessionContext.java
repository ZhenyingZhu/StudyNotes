package hello.beans;

// import com.amazon.ec2.centurion.util.concurrent.TimedExecutorService;

import java.util.Optional;

//import com.google.common.util.concurrent.ListeningScheduledExecutorService;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.support.GenericApplicationContext;

/**
 * Session context, which is defined in Spring.
 */
class SpringSessionContext extends GenericApplicationContext {
    private final String sessionDescriptor;
    private final BeanDefinitionRegistry registry;
    //private final TimedExecutorService sessionExecutor;

    private Optional<Session> session = Optional.empty();

    /**
     * Creates new SessionContext from the spring context.
     */
    public SpringSessionContext(final String sessionDescriptor,
                                final BeanDefinitionRegistry registry,
                                //final TimedExecutorService sessionExecutor,
                                final DefaultListableBeanFactory beanFactory) {
        super(beanFactory);

        setId(sessionDescriptor);

        this.sessionDescriptor = sessionDescriptor;
        this.registry = registry;
        //this.sessionExecutor = sessionExecutor;

        //log.trace("CREATED %s", sessionDescriptor.getSessionId());
    }

    @Override
    protected void prepareBeanFactory(ConfigurableListableBeanFactory beanFactory) {
        super.prepareBeanFactory(beanFactory);

        // Any bean registered here will get destroyed when session is closed. So we shouldn't pass
        // any shared objects here.
        beanFactory.registerSingleton("SessionDescriptor", sessionDescriptor);
        //beanFactory.registerSingleton("SessionExecutor", sessionExecutor);

        for (String beanName : registry.getBeanDefinitionNames()) {
            this.getDefaultListableBeanFactory().registerBeanDefinition(beanName, registry.getBeanDefinition(beanName));
        }
    }

    @Override
    protected void onRefresh() throws BeansException {
        //log.trace("ON_REFRESHING %s", sessionDescriptor.getSessionId());
        session = Optional.of(super.getBean(Session.class));
        //log.trace("ON_REFRESHED %s", sessionDescriptor.getSessionId(), session);
    }

    public Session getSession() {
        return this.session
                .orElseThrow(() -> new IllegalStateException("session is not initialized."));
    }

//    public ListeningScheduledExecutorService getExecutorService() {
//        return this.sessionExecutor;
//    }

    @Override
    public void start() {
        //log.info("STARTING %s", sessionDescriptor);
        super.start();
    }

    @Override
    public void stop() {
        //log.info("STOPPING %s", sessionDescriptor);
        super.stop();
    }

    @Override
    public void close() {
        //log.info("CLOSING %s", sessionDescriptor);
        super.close();
    }
}
