package hello.beans;

import java.util.ArrayList;
import java.util.concurrent.ScheduledExecutorService;

import com.google.common.util.concurrent.ListeningScheduledExecutorService;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.SimpleBeanDefinitionRegistry;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.core.io.Resource;

/**
 * SessionContext factory, which uses Spring bean factory to manage dependencies.
 */
public class SpringSessionContextFactory implements ApplicationContextAware, InitializingBean {

    private final BeanDefinitionRegistry registry = new SimpleBeanDefinitionRegistry();
    private final Resource resource;

    private ApplicationContext mainApplicationContext;
    private final Object[] excludedBeans;
    //private final ScheduledExecutorService globalExecutor;

    /**
     * D.I. Constructor
     */
    public SpringSessionContextFactory(Resource resource/*,
                                       Object[] excludedBeans,
                                       ScheduledExecutorService globalExecutor*/) {
        this.resource = resource;
        //this.globalExecutor = globalExecutor;
        //this.excludedBeans = ArrayUtils.clone(excludedBeans);
        this.excludedBeans = new Object[]{};
    }

    public SpringSessionContext newContext(String descriptor /*,
                                           ListeningScheduledExecutorService sessionExecutor*/) {
//        SelfCleaningScheduledExecutor mrClean =
//                new SelfCleaningScheduledExecutor(sessionExecutor, descriptor.getSessionId().toString());
//
//        TimedExecutorService timedExecutorService =
//                TimedExecutors.decorateExecutor(mrClean, globalExecutor);

        SpringSessionContext sessionContext = new SpringSessionContext(descriptor, registry,
                //timedExecutorService,
                new FilteredBeanFactory(excludedBeans));
        sessionContext.setParent(mainApplicationContext);
        sessionContext.refresh();

        //return new SessionContextAdapter(descriptor, sessionContext, mrClean);
        return sessionContext;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        mainApplicationContext = applicationContext;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        readSessionBeans();
    }

    private void readSessionBeans() {
        XmlBeanDefinitionReader xmlReader = new XmlBeanDefinitionReader(registry);
        xmlReader.setEnvironment(mainApplicationContext.getEnvironment());
        xmlReader.loadBeanDefinitions(resource);
    }

}
