package hello.beans;

/**
 * Created by zhenyinz on 4/12/17.
 */
public class Session {
    private String descriptor;

    public Session(String descriptor) {
        this.descriptor = descriptor;
    }

    public String getDescriptor() {
        return descriptor;
    }
}
