package hello.beans;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import com.google.common.collect.Sets;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationNotAllowedException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.InstantiationStrategy;
import org.springframework.beans.factory.support.RootBeanDefinition;

/**
 * Bean factory, which supports filtering of global beans from references.
 */
public class FilteredBeanFactory extends DefaultListableBeanFactory {

    public FilteredBeanFactory(Object[] excludedBeans) {
        InstantiationStrategy currentStrategy = getInstantiationStrategy();
        setInstantiationStrategy(new FilteredInstantiationStrategy(currentStrategy, excludedBeans));
    }

    @Override
    public String[] getBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
        String[] beanNames = super.getBeanNamesForType(type, includeNonSingletons, allowEagerInit);

        // lookup post processors in the parent factory
        if (BeanFactoryPostProcessor.class.equals(type)) {
            BeanFactory parentFactory = getParentBeanFactory();
            if (parentFactory instanceof ListableBeanFactory) {
                String[] parentBeans = (((ListableBeanFactory) parentFactory)
                        .getBeanNamesForType(type, includeNonSingletons, allowEagerInit));
                // if nothing in our context return parent
                if (beanNames.length == 0) {
                    return parentBeans;
                }
                // if nothing in parent context return ours
                if (parentBeans.length == 0) {
                    return beanNames;
                }
                // merge and return unique names from both
                Set<String> result = new HashSet<>();
                result.addAll(Arrays.asList(parentBeans));
                result.addAll(Arrays.asList(beanNames));
                return result.toArray(new String[result.size()]);
            }
        }

        return beanNames;
    }

    private static final class FilteredInstantiationStrategy implements InstantiationStrategy {

        private final InstantiationStrategy delegate;
        private final Set<Object> excludedBeans;

        private FilteredInstantiationStrategy(InstantiationStrategy delegate, Object[] excludedBeans) {
            this.delegate = delegate;
            this.excludedBeans = Sets.newIdentityHashSet();
            for (Object bean : excludedBeans) {
                this.excludedBeans.add(bean);
            }
        }

        @Override
        public Object instantiate(RootBeanDefinition beanDefinition,
                                  String beanName, BeanFactory owner) throws BeansException {
            return this.delegate.instantiate(beanDefinition, beanName, owner);
        }

        @Override
        public Object instantiate(RootBeanDefinition beanDefinition,
                                  String beanName, BeanFactory owner,
                                  Constructor<?> ctor, Object[] args) throws BeansException {
            verifyBeanArguments(beanName, args);
            return this.delegate.instantiate(beanDefinition, beanName, owner, ctor, args);
        }

        @Override
        public Object instantiate(RootBeanDefinition beanDefinition,
                                  String beanName, BeanFactory owner,
                                  Object factoryBean, Method factoryMethod, Object[] args) throws BeansException {
            verifyBeanArguments(beanName, args);
            return this.delegate.instantiate(beanDefinition, beanName, owner, factoryBean, factoryMethod, args);
        }

        private void verifyBeanArguments(String beanName, Object[] args) {
            for (Object bean : args) {
                if (excludedBeans.contains(bean)) {
                    throw new BeanCreationNotAllowedException(beanName,
                            "Detected forbidden dependency injection of type " + bean.getClass().getName());
                }
            }
        }
    }
}
