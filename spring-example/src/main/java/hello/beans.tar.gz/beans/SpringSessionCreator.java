package hello.beans;

import java.util.function.Supplier;

//import com.google.common.util.concurrent.ListeningScheduledExecutorService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Helper class, which creates a session by calling SessionCreator and wraps new session into Spring friendly holder.
 */
public class SpringSessionCreator implements Supplier<Session> {
    private final String descriptor;
    //private final ListeningScheduledExecutorService executor;

    /**
     * D.I. constructor
     */
    @Autowired
    public SpringSessionCreator(String descriptor/*,
                                ListeningScheduledExecutorService executor*/) {
        this.descriptor = descriptor;
        //this.executor = executor;
    }

    /**
     * Creates a new session
     */
    public Session newSession() {
        //log.trace("NEW_SESSION %s", descriptor.getSessionId());
        return new Session(descriptor);
    }

    @Override
    public Session get() {
        return newSession();
    }
}
